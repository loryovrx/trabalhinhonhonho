import logo from '../../assets/logo.png';

import tomate from '../../assets/frutas/Tomate.png';
import brocolis from '../../assets/frutas/Brocolis.png';
import batata from '../../assets/frutas/Batata.png';
import pepino from '../../assets/frutas/Pepino.png';
import abobora from '../../assets/frutas/Abobora.png';

const cesta = {
  topo: {
    titulo: "Detalhe da cesta",
  },
  detalhes: {
    nome: "Itens de salão de beleza",
    logoFazenda: logo,
    nomeFazenda: "Beauty Hair's",
    descricao: "Uma loja onde você encontra os melhores produtos para seus cabelos",
    preco: "R$ 50,00",
    botao: "Compre aqui",
  },
  itens: {
    titulo: "Itens da loja",
    
    lista: [
      {
        nome: "Shampoo",
        imagem: tomate,
        
      },
      {
        nome: "Secador de cabelos",
        imagem: brocolis,
      },
      {
        nome: "Creme hidratante",
        imagem: batata,
      },
      {
        nome: "Creme nutritivo",
        imagem: pepino,
      },
      {
        nome: "Óleo capilar",
        imagem: abobora,
      }
    ]
  }
}

export default cesta;